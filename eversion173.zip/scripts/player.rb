
class Player < Entity
	attr_accessor :shot, :nomove, :roll, :dead, :geddon
	def startup()
		log("player spawned @ "+self.x.to_s+","+self.y.to_s);
		self.collides=1;
 
 		@dead=false;
 		
 		a=1.0; b=0.5; c=1.0;
	 	a/=16;
	 	c/=256;
 		
 		vs = 4.0*a;
 		hs = 2.5*a;
 		va = 3.0*c;
 		ha = 1.5*c;
 		
#		a=2.0; b=0.8; c=2.0;
 

		@jumpspeed  =1.5*vs;
		@horzspeed  =1*hs;
		@rushspeed  =2*hs;
		@rollspeed  =2*hs;
		@rolldistance=5;
		
		@fallspeed  =1.5*vs;
	
		@jumpheight =1.5*b;
		@airjumpheight=(1.5*b);
	
		@airjumpsmax  =0;
		@airjumpspeed =(1.5*a);
		@airjumplimit =(2.5*b);
	
		@runaccel   =(4)*ha;
		@rundeccel  =(4)*ha;
		@airaccel   =(2)*ha;
		@airdeccel  =(2)*ha;
		@gravity    =(2)*va;

		@jump=0;
		@fall=false;
		
		@dir=0;
		@seq=0;
		@airjumps=0;
		@charge=0;
		@gun=0;
		
		@shot=0;
		
		@hit=0;
		@roll=0;
		
		@duck=false;
		@dead=false;
		
		@rush=0;
		@geddon=0;
		@jumped=0;
		@spike=0;
		
		$groundflag=0;
		@nomove=0;
	end
	def hurt()
		@spike+=2;
		die() if (@spike>3);
	end
	def die()
		return if (@dead);
		@dead=true;
		if ($darkness>4) then
			playSFX(6);
					for i in 1..8
						self.map.spawnEntity(BloodSplosion,"",x+0.5,y+0.5,(random(100)-50)*0.01,(random(100)-50)*0.01);
					end
					self.visible=0;
		else
			playSFX(5);
			self.ys=-2/16.0;
		end;
		self.collides=false;
		stopMusic();
		$restart=50;
	end
	def daemon()
		self.die() if (self.y>$cameray+18 && !$success)
		@spike-=1 if (@spike>0);
	
		if (@dead) then
			self.xs=0;
			self.ys+=1/16.0 if (self.ys<4/16.0);
			return;
		end
		
		self.x=$xwine/16.0-self.w if (self.x>$xwine/16.0-self.w && !$success)

		@geddon-=1 if (@geddon>0);
	

		self.map.bump(self,(self.x       ).to_i,(self.y+self.ys).to_i,self.map.getZone((self.x       ).to_i,(self.y+self.ys).to_i)) if (self.ys<0 && self.map.getZone((self.x       ).to_i,(self.y+self.ys).to_i)>0);	
		self.map.bump(self,(self.x+self.w-(1/16.0)).to_i,(self.y+self.ys).to_i,self.map.getZone((self.x+self.w-(1/16.0)).to_i,(self.y+self.ys).to_i)) if (self.ys<0 && (self.x+self.w-(1/16.0)).to_i != (self.x).to_i && self.map.getZone((self.x+self.w-(1/16.0)).to_i,(self.y+self.ys).to_i)>0);	


		self.map.step(self,(self.x       ).to_i,(self.y+self.h).to_i,self.map.getZone((self.x       ).to_i,(self.y+self.h).to_i)) if (self.map.getZone((self.x       ).to_i,(self.y+self.h).to_i)>0);	
		self.map.step(self,(self.x+self.w).to_i,(self.y+self.h).to_i,self.map.getZone((self.x+self.w).to_i,(self.y+self.h).to_i)) if ((self.x+self.w).to_i != (self.x).to_i && self.map.getZone((self.x+self.w).to_i,(self.y+self.h).to_i)>0);	

		self.map.event(self,(self.x+self.w/2).to_i,(self.y+self.h/2).to_i,self.map.getZone((self.x+self.w/2).to_i,(self.y+self.h/2).to_i)) if (self.map.getZone((self.x+self.w/2).to_i,(self.y+self.h/2).to_i)>0);
		
		$groundflag=1 if ($time_slow==2 && self.map.getZone((self.x+self.w/2).to_i,(self.y+self.h).to_i)==210)

		hspeed=@rush>10?@rushspeed:@horzspeed

		if (@nomove>0) then
			@nomove-=1;	
			self.xs=0;
			self.ys=0;
			return true;
		end

		mask=0xff0000; 
		
		
		
		
		
	  	u=getButton(7)>0;
		d=false;
	  	l=getButton(2)>0;
		r=getButton(3)>0;

		r=true if ($success)
		l=false if ($success)

		xs=self.xs;
		ys=self.ys;
		
		air=(@jump>0||@fall);
				
		@shot=nil;

		
		
		
		if (l && r) then
			l=false; r=false;
		end
		
		# (air?@airaccel:@runaccel)
		
    	xs -= @runaccel if (l && xs > -hspeed) 
  		if l then
  			@dir=1; @seq=1;
  		end
    	xs += @runaccel if (r && xs < hspeed) 
  		if r then
  			@dir=0; @seq=1;
  		end

   
   		if !l && !r then
   			xs-=@rundeccel*(xs<=>0) if xs!=0
   			xs=0 if self.xs*xs<=0
   			@seq=0 if !air
   		end
	
		if @jump>0 && ys<0 then
			@jump+=ys;
			@seq=2;
#			setButton(0,0) if ( @jump<=0 && ys>=0)
#		else
#			setButton(0,0) if @jump>0;
#			@jump=0;
		end
		@jump=0 if (self.ys>0);


		if (@jump<=0 && !self.isObstructedMask(2,0,0,0,mask) && $groundflag==0) then
			if (self.isObstructedMask(2,0,@horzspeed,0,mask)) then
     			ys=@horzspeed;
     		else
     			ys+=@gravity if (ys<@fallspeed); 
     			@seq=3 if (@fall); 
     			@fall=true;
     		end
  		else 
  			@fall=false;
  		end

		
	  if (self.isObstructedMask(2,0,0,0,mask) || $groundflag > 0) then
#      if (ys>=@fallspeed) playSFX(6);
  			ys=0 if ys>0;
      		@airjumps=@airjumpsmax; 
    	end


  		j=getButton(0)>0;
  		@jumped=0 if (!j);
				
		if (j && !@duck && @roll==0 && @jump<=0 && !@fall && !self.isObstructedMask(0,0,-0.5,0,mask) && @jumped<2) then
			@jump=@jumpheight; ys=-@jumpspeed; playSFX(0); 
			@jumped=1;
		end

		if (j && @jump<=0 && @roll==0 && @fall && @airjumps>0 && ys<@airjumplimit) then
			@jump=@airjumpheight; ys=-@airjumpspeed; @airjumps-=1; playSFX(0);
#        for (int i=0; i<10; i++)
#        objects->NewObject(x+5/16,y+1, (-64+(rand()%128))/2048.0, (128+(rand()%128))/2048.0, FLAG_OBSTRUCTABLE | FLAG_FADEOUT, 30, stuff, 4);
      	end

		if (!j) then 
			@jump=0; 
			ys+=@gravity if (ys<0);
		end
		
		@jumped=2 if (ys>=0 && @jumped==1)
		
		
		xs1=0; ys1=0;
  		step=1.0/16.0;

		# left
		xs1-=step while (xs1>xs && !self.isObstructedMask(3,xs1-step,0,-3,mask))
  		xs1=xs if (xs<0 && xs1<xs); 
  		# right
  		xs1+=step while (xs1<xs && !self.isObstructedMask(1,xs1+step,0,-3,mask))
  		xs1=xs if (xs>0 && xs1>xs); 
  		# up
  		ys1-=step while (ys1>ys && !self.isObstructedMask(0,xs1,ys1-step,0,mask))
  		ys1=ys if (ys<0 && ys1<ys);
  		# down
  		ys1+=step while (ys1<ys && !self.isObstructedMask(2,xs1,ys1,0,mask))
  		ys1=ys if (ys>0 && ys1>ys); 

  		ys1-=step while (self.isObstructedMask(2,xs1,ys1-step,0,mask))


		$groundflag=0;
		
		if (xs1!=xs) then self.x+=xs1; xs=0; end;
		if (ys1!=ys) then self.y+=ys1; ys=0; end;
		self.xs=xs;
		self.ys=ys;
		
		self.x=0 if (self.x<0)


		self.frame=0+@dir*4;
		self.frame=8+@dir*4+(self.counter/5)%4 if (l||r);
		self.frame=16+@dir*4+2 if @fall && ys>0;
		self.frame=16+@dir*4 if @jump>0||(@fall && ys<=0);
		
#  e->seq=e->seq%4;
#  if (gunflag>0) e->seq+=4;
		@hit-=1 if @hit>0;
		self.alpha=255;
		self.alpha=128 if ((@hit/5)%2==1)
	end
	def hit(e, damage)
		return true if @hit>0
		$health-=damage;
		@hit=50;
		self.xs=((e.x+e.w/2)<=>(self.x+self.w/2))*-@horzspeed;
		self.ys=-@jumpspeed/2;
	end
end

class KillsEnemies < Entity
	attr_accessor :power
end



class PlayerSlash < KillsEnemies
	def startup()
		@xp=($player.w/2)-(self.w/2)+((self.xs>0)?0.25:-0.25);
		@yp=($player.h/2)-0.4375-(self.h/2);
		self.frame=(self.xs>0)?0:1;
		self.xs=0;
		self.x=($player.x+@xp);
		self.y=($player.y+@yp);
		self.collides=1
		@power=1
	end
	def daemon()
		self.x=($player.x+@xp);
		self.y=($player.y+@yp);
		self.destroy() if ($player.roll<=0);
		self.alpha=383-self.alpha;
	end
	def die()
	end
end

class PlayerShot < KillsEnemies
	attr_accessor :timeout, :speed
	def startup()
		@rebounds=false
		@heavy=false
		@phase=false
		@bounces=3
		self.collides=1
		@timeout=80
		@speed=1
		@power=1
	end
	def setup(r, h, s, p)
		@rebounds=r
		@heavy=h
		@bounces=6 if @heavy
		@bounces=0 if s
		@timeout=20 if s
		self.frame=1 if @bounces>0
		self.frame=2 if @heavy
		@phase=p
		@power=3 if @heavy
	#	@power+=1 if $shot_speed > 1
	end
	def handlepos()
		@timeout-=1;
		return true if @timeout<=0;
		self.ys+=0.01*@speed if @heavy;
		b=false;
		if (!@phase) then
		if self.isObstructedMask(0,0,self.ys,0,0xff0000) || self.isObstructedMask(2,0,self.ys,0,0xff0000) then
			b=true; self.ys=-self.ys;
		end
		if self.isObstructedMask(1,self.xs,0,0,0xff0000) || self.isObstructedMask(3,self.xs,0,0,0xff0000) then
			b=true; self.xs=-self.xs;
		end
		end
		@bounces-=1 if b
		@timeout=80 if b
		return true if b && ( !@rebounds || @bounces<=0 || ((self.xs==0 || self.ys==0) && !@heavy) )
		return false;
	end	
	def daemon()
		if handlepos() then
			self.map.erode((self.x+self.xs).to_i,(self.y+self.ys).to_i);
			self.destroy() 
		end
		self.alpha=@timeout<10?@timeout*25:255;
	end
	def die()
		self.destroy();
	end
end

