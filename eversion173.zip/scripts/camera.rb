class Camera < Entity
	attr_accessor :xllimit, :xhlimit, :yllimit, :yhlimit;
	attr_accessor :xwinflag, :ywinflag;
	attr_accessor :xmove, :ymove;
	attr_accessor :trackspeed, :tracking, :tracker, :xtrack, :ytrack;
	attr_accessor :ysinheight, :ysinperiod;
	attr_accessor :rumble, :slow;
	def startup()
		@tracking=true;
		@tracker=$player;
		@trackspeed=1;
		@xwinflag=0;
		@ywinflag=0;
		@rumble=0;
		@slow=0;
		@xllimit=0;
		@xhlimit=9999;
		@yllimit=0;
		@yhlimit=9999;
		self.x=$player.x;
		self.y=$player.y;
	end
	def reset()
		@xllimit=$xwins+10.0;
		@yllimit=$ywins+6.5;
		@xhlimit=$xwine-10.0;
		@yhlimit=$ywine-6.5;
	end
	def activate()
		self.x=@xllimit if (self.x<@xllimit)
		self.y=@yllimit if (self.y<@yllimit)
		self.x=@xhlimit if (self.x>@xhlimit)
		self.y=@yhlimit if (self.y>@yhlimit)
	end
	def daemon()
		self.x=@tracker.x+@tracker.xs;
		self.y=@tracker.y+@tracker.ys;
		self.x=@xllimit if (self.x<@xllimit)
		self.y=@yllimit if (self.y<@yllimit)
		self.x=@xhlimit if (self.x>@xhlimit)
		self.y=@yhlimit if (self.y>@yhlimit)
		
	
	 if (@rumble>0) then
	 	self.x+=(random(5)-2)/16.0;
	 	self.y-=(random(5)-2)/16.0;
	 	@rumble-=1;
	 end
	end
	def event()
		@slow=1-@slow;
		@trackspeed=(2.5-@slow*1.5)/16;
	end
end