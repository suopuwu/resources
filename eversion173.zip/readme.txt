
"sounds - possibly musical - heard in the night from other worlds or realms of being."
commonplace book - h. p. lovecraft

eversion
(c) 2008-2009 guilherme s tows 
http://zarat.us/

not intended for children or those of a nervous disposition

if you appreciate this game please consider donating at http://zarat.us/

version 1.7.3

princess is kidnapped
you must save princess

z jumps
x everts in certain areas

p pauses
esc returns to title - you may re-start playing from any world you've reached
alt-x or alt-f4 close the game
alt-enter changes to/from fullscreen

music 1, intro and goal by matthew steele (http://zath.verge-rpg.com//)
musics 2, 3, 4, 5, 6 by miroslav malesevic (http://pqgames.exofire.net/)
music 7 by greyseraphim (http://freesound.org)
music 8 by blacklizard77 (http://freesound.org)

thanks to
zedpower for inspiration
lee-ham (http://lee-ham.deviantart.com/) for sasquatch
sharkey (http://sharkey.gamespite.net/) for polybius

ver 1.7.3 changes

- autoscroll section slightly slower
- enemies in world 7 revamped
- last world revamped
- new game mode added after game is finished
- copyrighted songs removed

ver 1.6 changes

- reduced acceleration again
- enemies in world 4 slightly more sensitive

ver 1.5 changes

- keyboard configuration added
- trying to patch memory issues. if you experience unexpected crashes, download version 1.4 instead
- last bit of world 4 reduced in difficulty
- fix world 7 end bug
- fix getting stuck in world 5
- finally fixed the jump controls
- autoscroll section slightly different
- remastered music for world 2, 3 and 4
- art fix






